// Austin Shipley
// Isaac Ehlers
// 3/26/2017
// parser.h for COP3402 System Software with Euripides Montagne HW3

#ifndef PARSER_H
#define PARSER_H

extern char** code;
extern int programCounter, halt;

extern void parser(int);

#endif
