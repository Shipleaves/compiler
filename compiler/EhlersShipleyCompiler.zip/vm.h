// Austin Shipley
// Isaac Ehlers
// 3/26/2017
// vm.h for COP3402 System Software with Euripides Montagne HW3

#ifndef VM_H
#define VM_H

extern void vm(int);

#endif
